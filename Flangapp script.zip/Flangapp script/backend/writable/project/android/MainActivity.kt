package {APP_ID}

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
